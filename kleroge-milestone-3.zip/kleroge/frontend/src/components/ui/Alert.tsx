import { clsx } from 'clsx';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

type AlertVariant = 'error' | 'success' | 'info';

interface AlertProps {
  variant?: AlertVariant;
  message: string | string[];
  className?: string;
}

const variants = {
  error:   { cls: 'bg-red-50 border-red-200 text-red-800',         Icon: AlertCircle  },
  success: { cls: 'bg-forest-50 border-forest-200 text-forest-800', Icon: CheckCircle2 },
  info:    { cls: 'bg-navy-50 border-navy-200 text-navy-800',       Icon: Info         },
};

export function Alert({ variant = 'error', message, className }: AlertProps) {
  const { cls, Icon } = variants[variant];
  const messages = Array.isArray(message) ? message : [message];
  return (
    <div role="alert" className={clsx('flex gap-3 rounded-lg border px-4 py-3 text-sm', cls, className)}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="flex flex-col gap-0.5">
        {messages.map((msg, i) => <p key={i}>{msg}</p>)}
      </div>
    </div>
  );
}
