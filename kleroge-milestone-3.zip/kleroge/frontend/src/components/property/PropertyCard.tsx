import Link from 'next/link';
import { MapPin, Maximize2, BedDouble, Bath } from 'lucide-react';
import { Property, PROPERTY_TYPE_LABELS, formatPrice, getPropertyImageUrl } from '@/lib/properties';

export function PropertyCard({ property }: { property: Property }) {
  const hasImage = property.imagePaths.length > 0;

  return (
    <Link href={`/properties/${property.id}`} className="card-hover block overflow-hidden group">
      {/* Image */}
      <div className="aspect-[4/3] bg-stone-100 relative overflow-hidden">
        {hasImage ? (
          <img
            src={getPropertyImageUrl(property.id, 0)}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-stone-200 flex items-center justify-center mx-auto mb-2">
                <span className="text-stone-400 text-xl">🏠</span>
              </div>
              <p className="text-xs text-stone-400">No image</p>
            </div>
          </div>
        )}
        {/* Type badge */}
        <div className="absolute top-3 left-3">
          <span className="badge-navy text-[10px] bg-white/90 backdrop-blur-sm border-0 shadow-sm">
            {PROPERTY_TYPE_LABELS[property.propertyType]}
          </span>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="font-semibold text-navy-950 text-sm leading-snug mb-1 line-clamp-1">{property.title}</p>
        <div className="flex items-center gap-1 text-stone-400 text-xs mb-3">
          <MapPin className="w-3 h-3 shrink-0" />
          <span className="truncate">{property.city}, {property.country}</span>
        </div>

        {/* Stats */}
        {(property.areaSqm || property.bedrooms || property.bathrooms) && (
          <div className="flex items-center gap-3 mb-3 text-xs text-stone-500">
            {property.areaSqm && (
              <span className="flex items-center gap-1">
                <Maximize2 className="w-3 h-3" />{property.areaSqm}m²
              </span>
            )}
            {property.bedrooms != null && (
              <span className="flex items-center gap-1">
                <BedDouble className="w-3 h-3" />{property.bedrooms} bed
              </span>
            )}
            {property.bathrooms != null && (
              <span className="flex items-center gap-1">
                <Bath className="w-3 h-3" />{property.bathrooms} bath
              </span>
            )}
          </div>
        )}

        {/* Price */}
        <div className="flex items-center justify-between pt-3 border-t border-stone-100">
          <p className="font-display font-bold text-navy-950 text-base">
            {formatPrice(property.price, property.currency)}
          </p>
          <span className="text-gold-600 text-xs font-semibold">View →</span>
        </div>
      </div>
    </Link>
  );
}
