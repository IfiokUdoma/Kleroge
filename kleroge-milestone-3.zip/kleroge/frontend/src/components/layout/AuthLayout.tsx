import React from 'react';

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex">

      {/* Brand panel */}
      <div
        className="hidden lg:flex lg:w-[42%] xl:w-[45%] flex-col justify-between p-14 relative overflow-hidden"
        style={{
          background: 'linear-gradient(160deg, #0f1528 0%, #1a2240 45%, #17693d 100%)',
        }}
      >
        {/* Gold geometric accent lines */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 500 700" preserveAspectRatio="xMidYMid slice">
          <line x1="0" y1="700" x2="500" y2="0" stroke="#d09d15" strokeWidth="80"/>
          <line x1="-100" y1="700" x2="400" y2="0" stroke="#d09d15" strokeWidth="2"/>
          <line x1="100" y1="700" x2="600" y2="0" stroke="#d09d15" strokeWidth="2"/>
        </svg>

        {/* Globe grid overlay */}
        <svg className="absolute top-0 right-0 w-72 h-72 opacity-[0.06]" viewBox="0 0 200 200">
          <circle cx="100" cy="100" r="90" fill="none" stroke="white" strokeWidth="1"/>
          <circle cx="100" cy="100" r="60" fill="none" stroke="white" strokeWidth="1"/>
          <circle cx="100" cy="100" r="30" fill="none" stroke="white" strokeWidth="1"/>
          <line x1="10" y1="100" x2="190" y2="100" stroke="white" strokeWidth="1"/>
          <line x1="100" y1="10" x2="100" y2="190" stroke="white" strokeWidth="1"/>
          <ellipse cx="100" cy="100" rx="90" ry="35" fill="none" stroke="white" strokeWidth="1"/>
          <ellipse cx="100" cy="100" rx="90" ry="65" fill="none" stroke="white" strokeWidth="1"/>
        </svg>

        {/* Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
            <span className="font-display text-white font-bold text-lg">K</span>
          </div>
          <div>
            <p className="font-display text-white font-semibold text-xl tracking-tight leading-none">Kleroge</p>
            <p className="text-gold-400 text-[9px] uppercase tracking-[0.2em] mt-0.5 font-medium">Global Real Estate</p>
          </div>
        </div>

        {/* Headline */}
        <div className="relative z-10">
          <div className="w-10 h-0.5 bg-gold-500 mb-8"/>
          <h1 className="font-display text-5xl xl:text-6xl font-bold text-white leading-[1.05] mb-6">
            Own.<br/>
            Secure.<br/>
            <span className="text-gold-400">Inherit.</span>
          </h1>
          <p className="text-navy-200 text-sm leading-relaxed max-w-xs">
            The digital infrastructure for borderless property ownership.
            Discover, acquire, and own real estate — anywhere on earth.
          </p>
        </div>

        {/* Footer */}
        <div className="relative z-10 flex items-center justify-between">
          <p className="text-navy-400 text-xs">© {new Date().getFullYear()} Kleroge · Khokmah Technologies</p>
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-gold-500"/>
            <div className="w-1.5 h-1.5 rounded-full bg-forest-500"/>
            <div className="w-1.5 h-1.5 rounded-full bg-navy-400"/>
          </div>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col bg-stone-50">
        {/* Mobile header */}
        <div className="lg:hidden flex items-center gap-3 px-6 py-4 border-b border-stone-200 bg-white">
          <div className="w-8 h-8 rounded-full bg-navy-950 flex items-center justify-center">
            <span className="font-display text-white font-bold text-sm">K</span>
          </div>
          <div>
            <p className="font-display font-semibold text-navy-950 text-base leading-none">Kleroge</p>
            <p className="text-gold-600 text-[9px] uppercase tracking-[0.15em]">Global Real Estate</p>
          </div>
        </div>

        <div className="flex-1 flex items-center justify-center p-6 py-12">
          <div className="w-full max-w-md">{children}</div>
        </div>
      </div>
    </div>
  );
}
