'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { LogOut, User, ShieldCheck, Home, PlusSquare, Search } from 'lucide-react';

export function Navbar() {
  const { user, signOut } = useAuth();
  const router = useRouter();

  const handleSignOut = async () => {
    await signOut();
    router.push('/auth/login');
  };

  return (
    <header className="bg-white border-b border-stone-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">

        {/* Logo mark */}
        <Link href="/dashboard" className="flex items-center gap-3 group shrink-0">
          <div className="w-9 h-9 rounded-full bg-navy-950 flex items-center justify-center shadow-sm group-hover:ring-2 group-hover:ring-gold-400 transition-all duration-200">
            <span className="font-display text-white font-bold text-base">K</span>
          </div>
          <div className="leading-none hidden sm:block">
            <p className="font-display font-semibold text-navy-950 text-lg tracking-tight leading-none">Kleroge</p>
            <p className="text-gold-600 text-[9px] font-semibold uppercase tracking-[0.18em] mt-0.5">Global Real Estate</p>
          </div>
        </Link>

        {/* Nav links */}
        {user && (
          <nav className="hidden md:flex items-center gap-0.5 flex-1 justify-center">
            <Link href="/dashboard" className="btn-ghost text-xs gap-1.5">
              <Home className="w-3.5 h-3.5" /> Dashboard
            </Link>
            <Link href="/properties" className="btn-ghost text-xs gap-1.5">
              <Search className="w-3.5 h-3.5" /> Browse
            </Link>
            {user.role === 'seller' && (
              <Link href="/properties/new" className="btn-ghost text-xs gap-1.5">
                <PlusSquare className="w-3.5 h-3.5" /> List Property
              </Link>
            )}
          </nav>
        )}

        {/* Right */}
        {user && (
          <div className="flex items-center gap-2 shrink-0">
            {user.kycStatus === 'approved' ? (
              <span className="badge-green text-[10px] hidden sm:inline-flex">
                <ShieldCheck className="w-3 h-3" /> Verified
              </span>
            ) : user.kycStatus === 'pending' ? (
              <span className="badge-gold text-[10px] hidden sm:inline-flex">Under review</span>
            ) : (
              <Link href="/kyc" className="badge-red text-[10px] hidden sm:inline-flex hover:opacity-80 transition-opacity">
                ! Verify identity
              </Link>
            )}

            <div className="flex items-center gap-2 pl-3 border-l border-stone-200">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-navy-100 to-navy-200 flex items-center justify-center">
                <User className="w-4 h-4 text-navy-600" />
              </div>
              <div className="hidden sm:block">
                <p className="text-xs font-semibold text-navy-900 leading-none">{user.fullName.split(' ')[0]}</p>
                <p className="text-[10px] text-stone-400 capitalize mt-0.5">{user.role}</p>
              </div>
              <button onClick={handleSignOut} className="btn-ghost p-2" title="Sign out">
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
