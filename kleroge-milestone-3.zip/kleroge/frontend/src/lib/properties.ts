import apiClient from './api-client';

export type PropertyType = 'residential' | 'commercial' | 'land' | 'industrial' | 'mixed_use';
export type ListingStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'sold' | 'delisted';
export type PropertyCurrency = 'USD' | 'GBP' | 'EUR' | 'NGN' | 'GHS' | 'KES' | 'ZAR' | 'AED';

export interface Property {
  id: string;
  sellerId: string;
  title: string;
  description: string;
  propertyType: PropertyType;
  country: string;
  city: string;
  address: string | null;
  price: number;
  currency: PropertyCurrency;
  areaSqm: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  imagePaths: string[];
  status: ListingStatus;
  rejectionReason: string | null;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePropertyPayload {
  title: string;
  description: string;
  propertyType: PropertyType;
  country: string;
  city: string;
  address?: string;
  price: number;
  currency: PropertyCurrency;
  areaSqm?: number;
  bedrooms?: number;
  bathrooms?: number;
}

export async function createProperty(payload: CreatePropertyPayload): Promise<Property> {
  const { data } = await apiClient.post<Property>('/properties', payload);
  return data;
}

export async function uploadPropertyImage(propertyId: string, file: File, onProgress?: (pct: number) => void): Promise<Property> {
  const formData = new FormData();
  formData.append('file', file);
  const { data } = await apiClient.post<Property>(`/properties/${propertyId}/images`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e => { if (onProgress && e.total) onProgress(Math.round((e.loaded / e.total) * 100)); },
  });
  return data;
}

export async function submitPropertyForApproval(propertyId: string): Promise<Property> {
  const { data } = await apiClient.patch<Property>(`/properties/${propertyId}/submit`);
  return data;
}

export async function getMyListings(): Promise<Property[]> {
  const { data } = await apiClient.get<Property[]>('/properties/seller/my-listings');
  return data;
}

export async function getApprovedListings(filters?: { country?: string; city?: string; type?: string }): Promise<Property[]> {
  const { data } = await apiClient.get<Property[]>('/properties', { params: filters });
  return data;
}

export async function getPropertyById(id: string): Promise<Property> {
  const { data } = await apiClient.get<Property>(`/properties/${id}`);
  return data;
}

export function getPropertyImageUrl(propertyId: string, index: number): string {
  const base = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api/v1';
  return `${base}/properties/${propertyId}/images/${index}`;
}

export const PROPERTY_TYPE_LABELS: Record<PropertyType, string> = {
  residential: 'Residential',
  commercial:  'Commercial',
  land:        'Land',
  industrial:  'Industrial',
  mixed_use:   'Mixed Use',
};

export const STATUS_LABELS: Record<ListingStatus, string> = {
  draft:    'Draft',
  pending:  'Under Review',
  approved: 'Live',
  rejected: 'Rejected',
  sold:     'Sold',
  delisted: 'Delisted',
};

export const STATUS_BADGE: Record<ListingStatus, string> = {
  draft:    'badge-gray',
  pending:  'badge-gold',
  approved: 'badge-green',
  rejected: 'badge-red',
  sold:     'badge-navy',
  delisted: 'badge-gray',
};

export function formatPrice(price: number, currency: PropertyCurrency): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(price);
}
