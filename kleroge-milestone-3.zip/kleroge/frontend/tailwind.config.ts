import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Navy — primary brand, from the wordmark
        navy: {
          50:  '#f0f2f8',
          100: '#dde2f0',
          200: '#bdc8e3',
          300: '#90a2ce',
          400: '#6077b4',
          500: '#415a9b',
          600: '#334783',
          700: '#2b3a6b',
          800: '#27335a',
          900: '#1a2240',
          950: '#0f1528',
        },
        // Gold — accent, from logo diagonal stripes
        gold: {
          50:  '#fdfaeb',
          100: '#faf2c7',
          200: '#f5e38b',
          300: '#efce4e',
          400: '#e8b820',
          500: '#d09d15',
          600: '#a87b10',
          700: '#875b11',
          800: '#6f4915',
          900: '#5e3c17',
        },
        // Forest — from the globe/tile element
        forest: {
          50:  '#f0faf4',
          100: '#dcf5e6',
          200: '#bbebce',
          300: '#88d8ab',
          400: '#4fbe80',
          500: '#28a05e',
          600: '#1a824a',
          700: '#17693d',
          800: '#165433',
          900: '#13452b',
          950: '#092618',
        },
        // Neutral surface
        stone: {
          50:  '#fafaf8',
          100: '#f5f5f0',
          200: '#ebebе4',
          300: '#d6d6ce',
          400: '#a8a89e',
          500: '#78786e',
        },
      },
      fontFamily: {
        display: ['Playfair Display', 'Georgia', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        DEFAULT: '8px',
        lg: '12px',
        xl: '16px',
        '2xl': '20px',
      },
      boxShadow: {
        card: '0 1px 3px rgba(15,21,40,0.06), 0 4px 16px rgba(15,21,40,0.04)',
        'card-hover': '0 4px 12px rgba(15,21,40,0.10), 0 12px 32px rgba(15,21,40,0.08)',
        gold: '0 0 0 3px rgba(208,157,21,0.25)',
      },
    },
  },
  plugins: [],
};

export default config;
