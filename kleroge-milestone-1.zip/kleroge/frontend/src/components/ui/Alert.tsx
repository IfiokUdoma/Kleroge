import { clsx } from 'clsx';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

type AlertVariant = 'error' | 'success' | 'info';

interface AlertProps {
  variant?: AlertVariant;
  message: string | string[];
  className?: string;
}

const variants: Record<AlertVariant, { bg: string; border: string; text: string; Icon: React.ComponentType<{ className?: string }> }> = {
  error: {
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-800',
    Icon: AlertCircle,
  },
  success: {
    bg: 'bg-primary-50',
    border: 'border-primary-200',
    text: 'text-primary-800',
    Icon: CheckCircle2,
  },
  info: {
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    text: 'text-blue-800',
    Icon: Info,
  },
};

export function Alert({ variant = 'error', message, className }: AlertProps) {
  const { bg, border, text, Icon } = variants[variant];
  const messages = Array.isArray(message) ? message : [message];

  return (
    <div
      role="alert"
      className={clsx(
        'flex gap-3 rounded-lg border px-4 py-3 text-sm',
        bg, border, text, className,
      )}
    >
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="flex flex-col gap-0.5">
        {messages.map((msg, i) => (
          <p key={i}>{msg}</p>
        ))}
      </div>
    </div>
  );
}
