export type UserRole = 'buyer' | 'seller' | 'admin';
export type KycStatus = 'not_started' | 'pending' | 'approved' | 'rejected';
export type AccountStatus = 'active' | 'suspended' | 'banned';

export interface User {
  id: string;
  fullName: string;
  email: string;
  emailVerified: boolean;
  phone: string | null;
  phoneVerified: boolean;
  country: string;
  preferredCurrency: string;
  role: UserRole;
  kycStatus: KycStatus;
  accountStatus: AccountStatus;
  createdAt: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // seconds
}

export interface AuthResponse {
  user: User;
  tokens: AuthTokens;
}

export interface ApiError {
  statusCode: number;
  message: string | string[];
  path: string;
  timestamp: string;
}

// Country options for the signup form
export interface CountryOption {
  code: string;
  name: string;
}

export const SUPPORTED_COUNTRIES: CountryOption[] = [
  { code: 'NG', name: 'Nigeria' },
  { code: 'US', name: 'United States' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'CA', name: 'Canada' },
  { code: 'GH', name: 'Ghana' },
  { code: 'KE', name: 'Kenya' },
  { code: 'ZA', name: 'South Africa' },
  { code: 'AE', name: 'United Arab Emirates' },
];
