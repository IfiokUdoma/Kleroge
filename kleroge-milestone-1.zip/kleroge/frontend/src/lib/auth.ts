import apiClient from './api-client';
import { clearTokens, setTokens } from './auth-storage';
import type { AuthResponse, AuthTokens, User } from '@/types';

export interface RegisterPayload {
  fullName: string;
  email: string;
  password: string;
  country: string;
  role: 'buyer' | 'seller';
}

export interface LoginPayload {
  email: string;
  password: string;
}

export async function register(payload: RegisterPayload): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>('/auth/register', payload);
  setTokens(data.tokens);
  return data;
}

export async function login(payload: LoginPayload): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>('/auth/login', payload);
  setTokens(data.tokens);
  return data;
}

export async function logout(refreshToken: string): Promise<void> {
  try {
    await apiClient.post('/auth/logout', { refreshToken });
  } finally {
    clearTokens();
  }
}

export async function getMe(): Promise<User> {
  const { data } = await apiClient.get<User>('/users/me');
  return data;
}

export async function refreshTokens(refreshToken: string): Promise<AuthTokens> {
  const { data } = await apiClient.post<AuthTokens>('/auth/refresh', { refreshToken });
  setTokens(data);
  return data;
}
