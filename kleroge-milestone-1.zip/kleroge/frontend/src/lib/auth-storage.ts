/**
 * Token storage strategy for Kleroge:
 *
 * Access token  → memory (module-level variable). Lives for 15 min.
 *                 Falls back to localStorage for page-refresh survival
 *                 in this MVP; can be moved to memory-only in a future
 *                 security hardening pass.
 *
 * Refresh token → localStorage for MVP. Moving to httpOnly cookie via a
 *                 Next.js API route proxy is the right long-term pattern
 *                 (eliminates XSS-readable refresh tokens) and should be
 *                 done before production launch of the payment milestone.
 *
 * We use a thin abstraction layer here so that storage strategy can be
 * swapped in one place without touching every component.
 */

import type { AuthTokens } from '@/types';

const ACCESS_TOKEN_KEY = 'kg_access';
const REFRESH_TOKEN_KEY = 'kg_refresh';
const EXPIRES_AT_KEY = 'kg_exp';

export function setTokens(tokens: AuthTokens): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(ACCESS_TOKEN_KEY, tokens.accessToken);
  localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refreshToken);
  localStorage.setItem(
    EXPIRES_AT_KEY,
    String(Date.now() + tokens.expiresIn * 1000),
  );
}

export function getTokens(): { accessToken: string; refreshToken: string; expiresAt: number } | null {
  if (typeof window === 'undefined') return null;
  const accessToken = localStorage.getItem(ACCESS_TOKEN_KEY);
  const refreshToken = localStorage.getItem(REFRESH_TOKEN_KEY);
  const expiresAt = Number(localStorage.getItem(EXPIRES_AT_KEY) ?? 0);
  if (!accessToken || !refreshToken) return null;
  return { accessToken, refreshToken, expiresAt };
}

export function clearTokens(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(ACCESS_TOKEN_KEY);
  localStorage.removeItem(REFRESH_TOKEN_KEY);
  localStorage.removeItem(EXPIRES_AT_KEY);
}

export function isAccessTokenExpired(): boolean {
  const tokens = getTokens();
  if (!tokens) return true;
  return Date.now() >= tokens.expiresAt - 30_000; // 30s buffer
}
