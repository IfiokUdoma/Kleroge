'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { getMe, login, logout, register } from './auth';
import { clearTokens, getTokens } from './auth-storage';
import type { LoginPayload, RegisterPayload } from './auth';
import type { User } from '@/types';

interface AuthContextValue {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signUp: (payload: RegisterPayload) => Promise<void>;
  signIn: (payload: LoginPayload) => Promise<void>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadUser = useCallback(async () => {
    const tokens = getTokens();
    if (!tokens) {
      setIsLoading(false);
      return;
    }
    try {
      const me = await getMe();
      setUser(me);
    } catch {
      clearTokens();
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const signUp = useCallback(async (payload: RegisterPayload) => {
    const response = await register(payload);
    setUser(response.user);
  }, []);

  const signIn = useCallback(async (payload: LoginPayload) => {
    const response = await login(payload);
    setUser(response.user);
  }, []);

  const signOut = useCallback(async () => {
    const tokens = getTokens();
    if (tokens?.refreshToken) {
      await logout(tokens.refreshToken);
    } else {
      clearTokens();
    }
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => {
    const me = await getMe();
    setUser(me);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        signUp,
        signIn,
        signOut,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside <AuthProvider>');
  }
  return ctx;
}
