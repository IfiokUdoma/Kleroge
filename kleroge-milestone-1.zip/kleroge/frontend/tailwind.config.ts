import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Kleroge brand palette
        // Primary: deep forest green — land, ownership, wealth, earth
        primary: {
          50:  '#f0faf4',
          100: '#dcf5e6',
          200: '#bbebce',
          300: '#88d8ab',
          400: '#4fbe80',
          500: '#28a05e',
          600: '#1a824a',
          700: '#17693d',
          800: '#165433',
          900: '#13452b',
          950: '#092618',
        },
        // Accent: warm gold — prosperity, generational wealth, prestige
        accent: {
          50:  '#fdfaeb',
          100: '#faf2c7',
          200: '#f4e38b',
          300: '#edce4e',
          400: '#e6bb27',
          500: '#d09d15',
          600: '#a87b10',
          700: '#875b11',
          800: '#704916',
          900: '#5f3d18',
        },
        // Surface neutrals — warm off-white background, stone-derived
        surface: {
          50:  '#fafaf8',
          100: '#f4f4f0',
          200: '#e8e8e2',
          300: '#d4d4cc',
        },
      },
      fontFamily: {
        // Display: Playfair Display — authoritative, editorial, land-registry feeling
        display: ['Playfair Display', 'Georgia', 'serif'],
        // Body: Inter — legible, modern, globally accessible
        body: ['Inter', 'system-ui', 'sans-serif'],
        // Mono: for property IDs, codes, reference numbers
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        DEFAULT: '8px',
        lg: '12px',
        xl: '16px',
      },
    },
  },
  plugins: [],
};

export default config;
