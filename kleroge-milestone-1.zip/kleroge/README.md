# Kleroge

**The digital infrastructure for property ownership.**
*Discover, acquire, and own property anywhere.*

---

## Milestone 1 — Foundation

Includes: project scaffold · Postgres schema · JWT auth (access + refresh tokens with rotation and revocation) · user signup/login/profile API · Next.js frontend with register, login, and dashboard screens.

---

## Prerequisites

- Node.js 18+
- PostgreSQL 15+
- npm 9+

---

## Backend Setup

```bash
cd backend

# 1. Install dependencies
npm install

# 2. Create your .env file
cp .env.example .env
# Then open .env and fill in:
#   DB_USERNAME, DB_PASSWORD, DB_NAME  → your local Postgres credentials
#   JWT_ACCESS_SECRET                  → run: openssl rand -base64 64
#   JWT_REFRESH_SECRET                 → run: openssl rand -base64 64

# 3. Create the Postgres database
psql -U postgres -c "CREATE DATABASE kleroge_dev;"
psql -U postgres -c "CREATE USER kleroge WITH PASSWORD 'changeme';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE kleroge_dev TO kleroge;"

# 4. Run migrations (creates users + refresh_tokens tables)
npm run migration:run

# 5. Start the dev server
npm run start:dev
```

API runs at: `http://localhost:3000`
Swagger docs: `http://localhost:3000/docs`

---

## Frontend Setup

```bash
cd frontend

# 1. Install dependencies
npm install

# 2. Create .env.local
cp .env.local.example .env.local
# No changes needed for local development

# 3. Start the dev server
npm run dev
```

Frontend runs at: `http://localhost:3001`

---

## API Endpoints — Milestone 1

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/api/v1/auth/register` | Create account | None |
| POST | `/api/v1/auth/login` | Sign in | None |
| POST | `/api/v1/auth/refresh` | Rotate refresh token | None |
| POST | `/api/v1/auth/logout` | Revoke session | None |
| POST | `/api/v1/auth/logout-all` | Revoke all sessions | Bearer |
| GET  | `/api/v1/users/me` | Get own profile | Bearer |
| PATCH | `/api/v1/users/me` | Update profile | Bearer |

Rate limits: 5 req/min on register and login · 10 req/min on refresh · 100 req/min global.

---

## Test Scenarios for Milestone 1

Work through these before signalling ready for Milestone 2:

1. **Register** a buyer account → receive `accessToken` + `refreshToken` in response
2. **Register** a seller account with a different email → succeeds
3. **Register** with an unsupported country code (e.g. `"XX"`) → `400` error with a clear message
4. **Register** with a weak password (e.g. `"password123"`) → `400` validation error
5. **Register** with the same email twice → `409` conflict (vague message — doesn't confirm the email exists)
6. **Login** with correct credentials → `200` + tokens
7. **Login** with wrong password → `401` (same message as wrong email — no enumeration)
8. **GET `/users/me`** with a valid access token → returns user profile (no `passwordHash` field in response)
9. **GET `/users/me`** with no token → `401`
10. **GET `/users/me`** with an expired/tampered token → `401`
11. **POST `/auth/refresh`** with a valid refresh token → new tokens issued, old one revoked
12. **POST `/auth/refresh`** with the same refresh token again (after rotation) → `401` + all sessions for that user are revoked (token theft detection)
13. **POST `/auth/logout`** → `204`, then using the old refresh token → `401`
14. **POST `/auth/logout-all`** → all sessions gone, existing access tokens rejected on next request
15. **PATCH `/users/me`** → update `fullName` or `country` → changes persist on next GET
16. **Swagger UI** at `/docs` works and shows all endpoints with auth lock icons

---

## Project Structure

```
kleroge/
├── backend/
│   ├── src/
│   │   ├── auth/              # JWT auth, refresh tokens, strategies
│   │   ├── users/             # User entity, profile endpoints
│   │   ├── common/            # Guards, decorators, filters
│   │   ├── config/            # Env loading, startup validation
│   │   └── database/
│   │       └── migrations/    # Schema changes — never synchronize:true
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── app/
    │   │   ├── auth/login/    # Login page
    │   │   ├── auth/register/ # Register page
    │   │   └── dashboard/     # Post-login landing (stub for M2)
    │   ├── components/
    │   │   ├── ui/            # FormField, SelectField, Alert, Spinner
    │   │   └── layout/        # AuthLayout (brand panel + form panel)
    │   └── lib/               # API client, auth context, token storage
    ├── .env.local.example
    └── package.json
```

---

## Design Tokens

| Token | Value | Usage |
|-------|-------|-------|
| Primary 700 | `#17693d` | Buttons, links, brand |
| Primary 800 | `#165433` | Hover states |
| Accent 500 | `#d09d15` | Highlights, prosperity cues |
| Surface 50 | `#fafaf8` | Page background |
| Display font | Playfair Display | Headings, brand mark |
| Body font | Inter | All UI text |

---

## Architecture Decisions Made in Milestone 1

- **`synchronize: false`** — all schema changes go through reviewed migrations
- **`tokenVersion` on User** — bumping this invalidates all outstanding access tokens immediately without a blocklist (O(1) revocation per authenticated request)
- **Refresh token rotation** — every use issues a new token and revokes the old; reuse of a revoked token nukes all sessions for that user (token theft detection)
- **Refresh tokens hashed at rest** — SHA-256, same principle as passwords
- **Password hash `select: false`** — never returned by default queries; fetched explicitly only in the login path
- **All errors from a single `AllExceptionsFilter`** — raw DB errors and stack traces never reach the client
- **`whitelist: true` on ValidationPipe** — unknown fields stripped from every request body
- **Country allowlist** — not "any ISO code" but an explicit list that grows as legal/compliance approves each jurisdiction
