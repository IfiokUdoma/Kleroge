import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { CreateUserInput } from './dto/create-user.input';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { KycStatus } from './entities/user-enums';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
  ) {}

  async create(input: CreateUserInput): Promise<User> {
    const user = this.usersRepository.create(input);
    return this.usersRepository.save(user);
  }

  async findByEmailWithPassword(email: string): Promise<User | null> {
    return this.usersRepository.findOne({
      where: { email: email.toLowerCase() },
      select: [
        'id', 'fullName', 'email', 'passwordHash', 'role', 'kycStatus',
        'accountStatus', 'tokenVersion', 'country', 'preferredCurrency',
        'emailVerified', 'phone', 'phoneVerified', 'createdAt',
      ],
    });
  }

  async findByEmailOrNull(email: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { email: email.toLowerCase() } });
  }

  async findByIdOrNull(id: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { id } });
  }

  async updateProfile(id: string, dto: UpdateProfileDto): Promise<User> {
    await this.usersRepository.update(id, dto);
    const updated = await this.findByIdOrNull(id);
    if (!updated) throw new Error('User disappeared during update.');
    return updated;
  }

  async updateLastLogin(id: string): Promise<void> {
    await this.usersRepository.update(id, { lastLoginAt: new Date() });
  }

  async updateKycStatus(id: string, kycStatus: KycStatus): Promise<void> {
    await this.usersRepository.update(id, { kycStatus });
  }

  async bumpTokenVersion(id: string): Promise<void> {
    await this.usersRepository.increment({ id }, 'tokenVersion', 1);
  }

  async setPasswordHash(id: string, passwordHash: string): Promise<void> {
    await this.usersRepository.update(id, { passwordHash });
  }
}
