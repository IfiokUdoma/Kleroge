import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { KycDocument } from './entities/kyc-document.entity';
import { KycReviewLog, KycReviewAction } from './entities/kyc-review-log.entity';
import {
  KycDocumentStatus,
  KycDocumentType,
  REQUIRED_DOCUMENT_TYPES,
} from './entities/kyc-enums';
import { FileStorageService } from './file-storage.service';
import { UsersService } from '../users/users.service';
import { KycStatus } from '../users/entities/user-enums';
import { InjectRepository as IR } from '@nestjs/typeorm';

export interface UploadDocumentInput {
  userId: string;
  documentType: KycDocumentType;
  buffer: Buffer;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
}

export interface AdminReviewInput {
  adminId: string;
  action: 'approve' | 'reject';
  rejectionReason?: string;
}

@Injectable()
export class KycService {
  private readonly logger = new Logger(KycService.name);

  constructor(
    @InjectRepository(KycDocument)
    private readonly kycDocRepo: Repository<KycDocument>,
    @InjectRepository(KycReviewLog)
    private readonly reviewLogRepo: Repository<KycReviewLog>,
    private readonly fileStorage: FileStorageService,
    private readonly usersService: UsersService,
  ) {}

  /**
   * Upload or replace a single KYC document.
   * If the user already has a document of this type, the old file
   * is deleted and replaced. Users can re-upload until they submit.
   */
  async uploadDocument(input: UploadDocumentInput): Promise<KycDocument> {
    const user = await this.usersService.findByIdOrNull(input.userId);
    if (!user) throw new NotFoundException('User not found.');

    // Don't allow uploads if already approved
    if (user.kycStatus === KycStatus.APPROVED) {
      throw new ForbiddenException('Your KYC is already approved. No further uploads needed.');
    }

    // Don't allow new uploads while under review — must wait for outcome
    if (user.kycStatus === KycStatus.PENDING) {
      throw new ForbiddenException(
        'Your documents are currently under review. Please wait for the outcome before uploading again.',
      );
    }

    // Delete previous document of same type if it exists
    const existing = await this.kycDocRepo.findOne({
      where: { userId: input.userId, documentType: input.documentType },
      select: ['id', 'storagePath', 'userId', 'documentType', 'status',
               'originalName', 'mimeType', 'sizeBytes', 'rejectionReason',
               'reviewedByAdminId', 'reviewedAt', 'createdAt', 'updatedAt'],
    });

    if (existing) {
      this.fileStorage.deleteKycFile(existing.storagePath);
      await this.kycDocRepo.remove(existing);
    }

    // Save the file
    const stored = await this.fileStorage.saveKycFile(
      input.userId,
      input.documentType,
      input.buffer,
      input.originalName,
    );

    const doc = this.kycDocRepo.create({
      userId: input.userId,
      documentType: input.documentType,
      status: KycDocumentStatus.UPLOADED,
      originalName: input.originalName,
      mimeType: input.mimeType,
      sizeBytes: input.sizeBytes,
      storagePath: stored.storagePath,
    });

    return this.kycDocRepo.save(doc);
  }

  /**
   * Submit all uploaded documents for review.
   * Validates all required types are present before allowing submission.
   * Transitions user KYC status to PENDING.
   */
  async submitForReview(userId: string): Promise<void> {
    const user = await this.usersService.findByIdOrNull(userId);
    if (!user) throw new NotFoundException('User not found.');

    if (user.kycStatus === KycStatus.APPROVED) {
      throw new ForbiddenException('Already approved.');
    }
    if (user.kycStatus === KycStatus.PENDING) {
      throw new ForbiddenException('Already submitted and under review.');
    }

    const docs = await this.kycDocRepo.find({ where: { userId } });
    const uploadedTypes = docs.map((d) => d.documentType);

    const missingTypes = REQUIRED_DOCUMENT_TYPES.filter(
      (required) => !uploadedTypes.includes(required),
    );

    if (missingTypes.length > 0) {
      throw new BadRequestException(
        `Missing required documents: ${missingTypes.join(', ')}. Please upload all required documents before submitting.`,
      );
    }

    // Mark all docs as under review
    await this.kycDocRepo.update(
      { userId },
      { status: KycDocumentStatus.UNDER_REVIEW },
    );

    // Transition user KYC status
    await this.usersService.updateKycStatus(userId, KycStatus.PENDING);

    // Audit log
    await this.reviewLogRepo.save(
      this.reviewLogRepo.create({
        userId,
        action: KycReviewAction.SUBMITTED,
        adminId: null,
        note: `Submitted ${docs.length} document(s) for review.`,
      }),
    );

    this.logger.log(`User ${userId} submitted KYC for review.`);
  }

  /** Get all documents for a user (without storagePath — that's select:false) */
  async getDocumentsForUser(userId: string): Promise<KycDocument[]> {
    return this.kycDocRepo.find({
      where: { userId },
      order: { createdAt: 'DESC' },
    });
  }

  /** Get a signed (authorized) file stream for a document — only the owner or admin can call this */
  async getDocumentFile(
    documentId: string,
    requestingUserId: string,
    isAdmin: boolean,
  ): Promise<{ buffer: Buffer; mimeType: string; originalName: string }> {
    const doc = await this.kycDocRepo.findOne({
      where: { id: documentId },
      select: ['id', 'userId', 'storagePath', 'mimeType', 'originalName',
               'documentType', 'status', 'sizeBytes', 'rejectionReason',
               'reviewedByAdminId', 'reviewedAt', 'createdAt', 'updatedAt'],
    });

    if (!doc) throw new NotFoundException('Document not found.');

    if (!isAdmin && doc.userId !== requestingUserId) {
      throw new ForbiddenException('You do not have access to this document.');
    }

    const buffer = this.fileStorage.readKycFile(doc.storagePath);
    return { buffer, mimeType: doc.mimeType, originalName: doc.originalName };
  }

  /** Admin: get all pending KYC submissions */
  async getPendingSubmissions(): Promise<{ userId: string; documents: KycDocument[]; submittedAt: Date }[]> {
    const docs = await this.kycDocRepo.find({
      where: { status: KycDocumentStatus.UNDER_REVIEW },
      order: { updatedAt: 'ASC' },
    });

    // Group by userId
    const grouped = docs.reduce<Record<string, KycDocument[]>>((acc, doc) => {
      if (!acc[doc.userId]) acc[doc.userId] = [];
      acc[doc.userId].push(doc);
      return acc;
    }, {});

    return Object.entries(grouped).map(([userId, userDocs]) => ({
      userId,
      documents: userDocs,
      submittedAt: userDocs[0].updatedAt,
    }));
  }

  /** Admin: approve or reject a user's KYC submission */
  async reviewSubmission(userId: string, input: AdminReviewInput): Promise<void> {
    const user = await this.usersService.findByIdOrNull(userId);
    if (!user) throw new NotFoundException('User not found.');

    if (user.kycStatus !== KycStatus.PENDING) {
      throw new BadRequestException(
        `Cannot review — user KYC status is "${user.kycStatus}", not "pending".`,
      );
    }

    if (input.action === 'approve') {
      await this.kycDocRepo.update(
        { userId },
        { status: KycDocumentStatus.ACCEPTED, reviewedByAdminId: input.adminId, reviewedAt: new Date() },
      );
      await this.usersService.updateKycStatus(userId, KycStatus.APPROVED);
      await this.reviewLogRepo.save(
        this.reviewLogRepo.create({
          userId,
          action: KycReviewAction.APPROVED,
          adminId: input.adminId,
          note: 'All documents approved.',
        }),
      );
      this.logger.log(`Admin ${input.adminId} APPROVED KYC for user ${userId}`);
    } else {
      if (!input.rejectionReason?.trim()) {
        throw new BadRequestException('A rejection reason is required.');
      }
      await this.kycDocRepo.update(
        { userId },
        {
          status: KycDocumentStatus.REJECTED,
          rejectionReason: input.rejectionReason,
          reviewedByAdminId: input.adminId,
          reviewedAt: new Date(),
        },
      );
      await this.usersService.updateKycStatus(userId, KycStatus.REJECTED);
      await this.reviewLogRepo.save(
        this.reviewLogRepo.create({
          userId,
          action: KycReviewAction.REJECTED,
          adminId: input.adminId,
          note: input.rejectionReason,
        }),
      );
      this.logger.log(`Admin ${input.adminId} REJECTED KYC for user ${userId}: ${input.rejectionReason}`);
    }
  }

  /** Get KYC audit log for a user */
  async getReviewLog(userId: string): Promise<KycReviewLog[]> {
    return this.reviewLogRepo.find({
      where: { userId },
      order: { createdAt: 'ASC' },
    });
  }
}
