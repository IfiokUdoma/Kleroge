'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, CheckCircle2, Clock, Loader2, ShieldCheck, XCircle } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { KycDocument, getMyDocuments, submitKycForReview } from '@/lib/kyc';
import { UploadCard } from '@/components/kyc/UploadCard';
import { Alert } from '@/components/ui/Alert';
import { Spinner } from '@/components/ui/Spinner';

const UPLOAD_STEPS = [
  {
    key: 'passport' as const,
    endpoint: 'identity' as const,
    title: 'Passport or National ID',
    description: 'A clear photo of the front of your government-issued identity document.',
    hint: 'JPG, PNG, WEBP, or PDF · Max 10MB · Must be valid and not expired.',
  },
  {
    key: 'proof_of_address' as const,
    endpoint: 'address' as const,
    title: 'Proof of Address',
    description: 'A utility bill, bank statement, or official letter showing your name and address.',
    hint: 'Must be dated within the last 3 months · JPG, PNG, WEBP, or PDF · Max 10MB.',
  },
  {
    key: 'selfie' as const,
    endpoint: 'selfie' as const,
    title: 'Selfie',
    description: 'A clear photo of your face. Hold your ID next to your face for best results.',
    hint: 'JPG, PNG, or WEBP · Max 10MB · No filters or heavy editing.',
  },
];

export default function KycPage() {
  const router = useRouter();
  const { user, isLoading: authLoading, refreshUser } = useAuth();
  const [documents, setDocuments] = useState<KycDocument[]>([]);
  const [docsLoading, setDocsLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const loadDocuments = useCallback(async () => {
    try {
      const docs = await getMyDocuments();
      setDocuments(docs);
    } catch {
      // silently fail — user just won't see existing docs
    } finally {
      setDocsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && !user) router.replace('/auth/login');
    if (user) loadDocuments();
  }, [authLoading, user, router, loadDocuments]);

  const handleUploaded = (doc: KycDocument) => {
    setDocuments((prev) => {
      const filtered = prev.filter((d) => d.documentType !== doc.documentType);
      return [...filtered, doc];
    });
  };

  const getDoc = (type: string) => documents.find((d) => d.documentType === type);

  const allUploaded = UPLOAD_STEPS.every((step) => !!getDoc(step.key));
  const isUnderReview = user?.kycStatus === 'pending';
  const isApproved = user?.kycStatus === 'approved';
  const isRejected = user?.kycStatus === 'rejected';
  const isDisabled = isUnderReview || isApproved;

  const handleSubmit = async () => {
    setSubmitError(null);
    setSubmitting(true);
    try {
      await submitKycForReview();
      await refreshUser();
      setSubmitSuccess(true);
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setSubmitError(msg ?? 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading || docsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" className="text-primary-700" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-white border-b border-surface-200 px-6 py-4 flex items-center justify-between">
        <span className="font-display text-xl font-semibold text-primary-800">Kleroge</span>
        <Link href="/dashboard" className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1.5">
          <ArrowLeft className="w-4 h-4" />
          Back to dashboard
        </Link>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-10">

        {/* Page title */}
        <div className="flex items-center gap-3 mb-2">
          <ShieldCheck className="w-6 h-6 text-primary-700" />
          <h1 className="font-display text-2xl font-bold text-gray-900">
            Identity Verification
          </h1>
        </div>
        <p className="text-gray-500 text-sm mb-8 ml-9">
          Verify your identity to start buying or listing property on Kleroge.
          Your documents are stored securely and only reviewed by our compliance team.
        </p>

        {/* Status banners */}
        {isApproved && (
          <div className="flex items-center gap-3 p-4 bg-primary-50 border border-primary-200 rounded-xl mb-8">
            <CheckCircle2 className="w-5 h-5 text-primary-700 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-primary-800">Verification complete</p>
              <p className="text-xs text-primary-600 mt-0.5">
                Your identity has been verified. You can now transact on Kleroge.
              </p>
            </div>
          </div>
        )}

        {(isUnderReview || submitSuccess) && (
          <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-xl mb-8">
            <Clock className="w-5 h-5 text-blue-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-blue-800">Documents under review</p>
              <p className="text-xs text-blue-600 mt-0.5">
                Our compliance team is reviewing your documents. This typically takes 1–2 business days.
              </p>
            </div>
          </div>
        )}

        {isRejected && !submitSuccess && (
          <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-xl mb-8">
            <XCircle className="w-5 h-5 text-red-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-red-800">Verification rejected</p>
              <p className="text-xs text-red-600 mt-0.5">
                One or more documents were rejected. See the details below, upload new documents, and resubmit.
              </p>
            </div>
          </div>
        )}

        {/* Upload cards */}
        <div className="flex flex-col gap-4 mb-8">
          {UPLOAD_STEPS.map((step) => (
            <UploadCard
              key={step.key}
              title={step.title}
              description={step.description}
              hint={step.hint}
              endpoint={step.endpoint}
              existingDoc={getDoc(step.key)}
              disabled={isDisabled}
              onUploaded={handleUploaded}
            />
          ))}
        </div>

        {/* Submit section */}
        {!isApproved && !isUnderReview && !submitSuccess && (
          <div className="card p-5">
            <div className="flex items-start justify-between gap-6">
              <div>
                <p className="text-sm font-medium text-gray-900 mb-1">
                  {allUploaded
                    ? 'All documents uploaded — ready to submit'
                    : `${UPLOAD_STEPS.filter((s) => !!getDoc(s.key)).length} of ${UPLOAD_STEPS.length} documents uploaded`}
                </p>
                <p className="text-xs text-gray-500">
                  {allUploaded
                    ? 'Review your documents above, then submit for compliance review.'
                    : 'Upload all three documents before submitting.'}
                </p>
              </div>

              <button
                onClick={handleSubmit}
                disabled={!allUploaded || submitting}
                className="btn-primary shrink-0"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Submitting…
                  </>
                ) : (
                  'Submit for review'
                )}
              </button>
            </div>

            {submitError && <Alert message={submitError} className="mt-4" />}
          </div>
        )}
      </main>
    </div>
  );
}
