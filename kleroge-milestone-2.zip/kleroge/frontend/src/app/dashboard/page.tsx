'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowRight, ShieldCheck, ShieldAlert, Clock, ShieldOff } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { Spinner } from '@/components/ui/Spinner';

const kycConfig = {
  not_started: {
    icon: ShieldOff,
    label: 'Not verified',
    message: 'Complete identity verification to buy or list property on Kleroge.',
    color: 'text-gray-500 bg-gray-50 border-surface-200',
    iconColor: 'text-gray-400',
    cta: 'Start verification',
  },
  pending: {
    icon: Clock,
    label: 'Under review',
    message: 'Your documents are being reviewed. This typically takes 1–2 business days.',
    color: 'text-blue-700 bg-blue-50 border-blue-200',
    iconColor: 'text-blue-500',
    cta: 'View documents',
  },
  approved: {
    icon: ShieldCheck,
    label: 'Verified',
    message: 'Your identity is verified. You can now transact on Kleroge.',
    color: 'text-primary-700 bg-primary-50 border-primary-200',
    iconColor: 'text-primary-600',
    cta: null,
  },
  rejected: {
    icon: ShieldAlert,
    label: 'Action required',
    message: 'Your verification was rejected. Please resubmit your documents.',
    color: 'text-red-700 bg-red-50 border-red-200',
    iconColor: 'text-red-500',
    cta: 'Resubmit documents',
  },
};

export default function DashboardPage() {
  const { user, isLoading, isAuthenticated, signOut } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) router.replace('/auth/login');
  }, [isLoading, isAuthenticated, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" className="text-primary-700" />
      </div>
    );
  }

  if (!user) return null;

  const kyc = kycConfig[user.kycStatus] ?? kycConfig.not_started;
  const KycIcon = kyc.icon;

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-200 px-6 py-4 flex items-center justify-between">
        <span className="font-display text-xl font-semibold text-primary-800">Kleroge</span>
        <button
          onClick={async () => { await signOut(); router.push('/auth/login'); }}
          className="btn-secondary text-sm px-4 py-2"
        >
          Sign out
        </button>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <h1 className="font-display text-3xl font-bold text-gray-900 mb-1">
          Good day, {user.fullName.split(' ')[0]}
        </h1>
        <p className="text-gray-500 text-sm mb-10">
          {user.role === 'buyer' ? 'Buyer' : 'Seller'} · {user.country}
        </p>

        {/* KYC status card */}
        <div className={`card p-5 border mb-6 ${kyc.color}`}>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <KycIcon className={`w-5 h-5 shrink-0 ${kyc.iconColor}`} />
              <div>
                <p className="text-sm font-semibold">{kyc.label}</p>
                <p className="text-xs mt-0.5 opacity-80">{kyc.message}</p>
              </div>
            </div>
            {kyc.cta && (
              <Link
                href="/kyc"
                className="flex items-center gap-1.5 text-xs font-semibold shrink-0 hover:underline"
              >
                {kyc.cta}
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            )}
          </div>
        </div>

        {/* Profile card */}
        <div className="card p-6 grid grid-cols-2 gap-6 mb-6">
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Full name</p>
            <p className="text-sm font-medium text-gray-900">{user.fullName}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Email</p>
            <p className="text-sm font-medium text-gray-900">{user.email}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Country</p>
            <p className="text-sm font-medium text-gray-900">{user.country}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Account type</p>
            <p className="text-sm font-medium text-gray-900 capitalize">{user.role}</p>
          </div>
        </div>

        <p className="text-xs text-gray-400">
          Milestone 3 adds property listings. Coming next.
        </p>
      </main>
    </div>
  );
}
