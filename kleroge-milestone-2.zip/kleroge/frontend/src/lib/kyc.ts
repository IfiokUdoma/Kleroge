import apiClient from './api-client';

export interface KycDocument {
  id: string;
  documentType: 'passport' | 'national_id' | 'proof_of_address' | 'selfie';
  status: 'uploaded' | 'under_review' | 'accepted' | 'rejected';
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  rejectionReason: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface KycLogEntry {
  id: string;
  action: 'submitted' | 'approved' | 'rejected' | 'resubmitted';
  note: string | null;
  createdAt: string;
}

export async function getMyDocuments(): Promise<KycDocument[]> {
  const { data } = await apiClient.get<KycDocument[]>('/kyc/documents');
  return data;
}

export async function uploadKycFile(
  endpoint: 'identity' | 'address' | 'selfie',
  file: File,
  onProgress?: (pct: number) => void,
): Promise<KycDocument> {
  const formData = new FormData();
  formData.append('file', file);

  const { data } = await apiClient.post<KycDocument>(
    `/kyc/upload/${endpoint}`,
    formData,
    {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (onProgress && e.total) {
          onProgress(Math.round((e.loaded / e.total) * 100));
        }
      },
    },
  );
  return data;
}

export async function submitKycForReview(): Promise<void> {
  await apiClient.post('/kyc/submit');
}

export async function getKycLog(): Promise<KycLogEntry[]> {
  const { data } = await apiClient.get<KycLogEntry[]>('/kyc/log');
  return data;
}

/** Returns a blob URL to preview a document in-browser */
export async function getDocumentFileUrl(documentId: string): Promise<string> {
  const response = await apiClient.get(`/kyc/documents/${documentId}/file`, {
    responseType: 'blob',
  });
  return URL.createObjectURL(response.data as Blob);
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
