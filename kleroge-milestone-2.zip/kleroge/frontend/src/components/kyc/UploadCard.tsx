'use client';

import { useRef, useState } from 'react';
import { CheckCircle2, FileText, Loader2, Upload, X } from 'lucide-react';
import { clsx } from 'clsx';
import { KycDocument, formatFileSize, uploadKycFile } from '@/lib/kyc';

interface UploadCardProps {
  title: string;
  description: string;
  hint: string;
  endpoint: 'identity' | 'address' | 'selfie';
  existingDoc: KycDocument | undefined;
  disabled: boolean;
  onUploaded: (doc: KycDocument) => void;
}

export function UploadCard({
  title,
  description,
  hint,
  endpoint,
  existingDoc,
  disabled,
  onUploaded,
}: UploadCardProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const statusColors = {
    uploaded: 'text-accent-600 bg-accent-50 border-accent-200',
    under_review: 'text-blue-700 bg-blue-50 border-blue-200',
    accepted: 'text-primary-700 bg-primary-50 border-primary-200',
    rejected: 'text-red-700 bg-red-50 border-red-200',
  };

  const statusLabels = {
    uploaded: 'Uploaded',
    under_review: 'Under review',
    accepted: 'Accepted ✓',
    rejected: 'Rejected',
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Client-side size check (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError('File is too large. Maximum size is 10MB.');
      return;
    }

    setError(null);
    setUploading(true);
    setProgress(0);

    try {
      const doc = await uploadKycFile(endpoint, file, setProgress);
      onUploaded(doc);
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setError(msg ?? 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
      setProgress(0);
      // Reset file input so same file can be re-selected if needed
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const isComplete = existingDoc?.status === 'accepted';

  return (
    <div
      className={clsx(
        'card p-5 transition-all duration-200',
        isComplete && 'border-primary-200 bg-primary-50/30',
        disabled && 'opacity-60',
      )}
    >
      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-medium text-gray-900 text-sm">{title}</h3>
            {isComplete && <CheckCircle2 className="w-4 h-4 text-primary-600" />}
          </div>
          <p className="text-xs text-gray-500">{description}</p>
        </div>

        {existingDoc && (
          <span
            className={clsx(
              'text-xs font-medium px-2.5 py-1 rounded-full border shrink-0',
              statusColors[existingDoc.status],
            )}
          >
            {statusLabels[existingDoc.status]}
          </span>
        )}
      </div>

      {/* Existing file info */}
      {existingDoc && (
        <div className="flex items-center gap-2 mb-3 p-2.5 bg-surface-100 rounded-lg">
          <FileText className="w-4 h-4 text-gray-400 shrink-0" />
          <span className="text-xs text-gray-600 truncate flex-1">{existingDoc.originalName}</span>
          <span className="text-xs text-gray-400 shrink-0">{formatFileSize(existingDoc.sizeBytes)}</span>
        </div>
      )}

      {/* Rejection reason */}
      {existingDoc?.status === 'rejected' && existingDoc.rejectionReason && (
        <div className="flex gap-2 p-2.5 bg-red-50 border border-red-100 rounded-lg mb-3">
          <X className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
          <p className="text-xs text-red-700">{existingDoc.rejectionReason}</p>
        </div>
      )}

      {/* Upload progress */}
      {uploading && (
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-gray-500">Uploading…</span>
            <span className="text-xs text-gray-500">{progress}%</span>
          </div>
          <div className="h-1.5 bg-surface-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary-600 rounded-full transition-all duration-200"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Error */}
      {error && <p className="text-xs text-red-600 mb-3">{error}</p>}

      {/* Hint */}
      <p className="text-xs text-gray-400 mb-3">{hint}</p>

      {/* Upload button — hidden if accepted, disabled while under review */}
      {existingDoc?.status !== 'accepted' && existingDoc?.status !== 'under_review' && (
        <>
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept=".jpg,.jpeg,.png,.webp,.pdf"
            onChange={handleFileChange}
            disabled={disabled || uploading}
          />
          <button
            onClick={() => inputRef.current?.click()}
            disabled={disabled || uploading}
            className={clsx(
              'w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg',
              'border-2 border-dashed border-surface-200 text-sm text-gray-500',
              'hover:border-primary-400 hover:text-primary-700 hover:bg-primary-50/50',
              'transition-colors duration-150 disabled:cursor-not-allowed',
            )}
          >
            {uploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Upload className="w-4 h-4" />
            )}
            {existingDoc ? 'Replace file' : 'Choose file'}
          </button>
        </>
      )}
    </div>
  );
}
